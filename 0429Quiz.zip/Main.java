import java.util.Scanner;
import java.util.*;
import java.util.Random;

class Main {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    Random rand = new Random();

    //7-1
  //   System.out.print("정수 x : ");
  //   int x = sc.nextInt();

  //   int s = signOf(x);
  //   System.out.println("signOf(x)는" + s + "입니다.");
  // }

  //7-1
  // static int signOf(int i) {
  //   if (i > 1) {
  //     return 1;
  //   } else if(i == 0) {
  //     return 0;
  //   } else {
  //     return -1;
  //   }

    //7-2
  //   System.out.print("정수 a : ");
  //   int a = sc.nextInt();
  //   System.out.print("정수 b : ");
  //   int b = sc.nextInt();
  //   System.out.print("정수 c : ");
  //   int c = sc.nextInt();

  //   int s = min(a,b,c);
  //   System.out.println("최솟값은" + s + "입니다.");

  // }

  // static int min(int x, int y, int z) {
  //   if(x < y && x < z)
  //     return x;
  //   else if(y < x && y < z) 
  //     return y;
  //   else 
  //     return z;


  // 7-3
  //   System.out.print("정수 a : "); int a = sc.nextInt() ;
  //   System.out.print("정수 b : "); int b = sc.nextInt() ;
  //   System.out.print("정수 c : "); int c = sc.nextInt() ;

  //   System.out.println("중간값은 " + mid(a,b,c) + "입니다.");
  // }

  // static int mid(int a, int b, int c) {
    // if((x < y && x > z) || ( x < z && x > y)) return x;
    // if((y < x && y > z) || ( y < z && y > x)) return y;
    // else return z;
    // if(a >= b)
    //   if(b >= c)
    //     return b;
    //   else if(a <= c)
    //     return a;
    //   else  
    //     return c;
    // else if (a > c)
    //   return a;
    // else if (b > c)
    //   return c;
    // else 
    //   return b;


    //7-4
  //   System.out.println("1부터 x까지의 합을 구하시오");
  //   System.out.print("x의 값 : ");
  //   int x = sc.nextInt();

  //   System.out.println("1부터 " + x + "까지의 합은 " + sumUp(x) + " 입니다." );

  // }

  // static int sumUp(int x) {
  //   int sum = 0;
  //   for(int i = 0; i <= x; i++) {
  //     sum += i;
  //   }
  //   return sum;

    //7-6
  //   System.out.print("몇 월 입니까?(1~12) : ");
  //   int m = sc.nextInt();
  //   System.out.print("해당 월의 계절은 " + printSeason(m) + "입니다.");
  // }

  // static String printSeason(int month) {
  //   String m = "";
  //   switch(month) {
  //     case 3:
  //     case 4:
  //     case 5:
  //       m = "봄";
  //       break;
  //     case 6:
  //     case 7:
  //     case 8:
  //       m = "여름";
  //       break;
  //     case 9:
  //     case 10:
  //     case 11:
  //       m = "가을";
  //       break;
  //     case 12:
  //     case 1:
  //     case 2:
  //       m = "겨울";
  //       break;
  //   }
  //   return m;

    //7-7
  //   System.out.println("왼쪽 아래가 직각인 이등변 삼각형");
  //   System.out.print("단수는 : ");
  //   int n = sc.nextInt();

  //   for(int i = 1; i <=n ; i++) {
  //     putStart(i);
  //     System.out.println();
  //   }
    

  // }
  // static void putChar(char c, int n) {
  //   while(n-->0)
  //     System.out.print(c);
  // }


  // static void putStart(int n) {
  //   putChar('*',n);


    //7-8
  //   System.out.println("난수를 생성합니다.");
  //   System.out.print("하한값: ");
  //   int a = sc.nextInt();
  //   System.out.print("상한값: ");
  //   int b = sc.nextInt();

  //   System.out.print("생성한 난수는 " + random(a,b) + " 입니다.");

  // }

  // static int random(int a, int b) {
  //   if(b <= a) {
  //     return a;
  //   } else {
  //     Random rand = new Random();
  //     return a + rand.nextInt(b-a+1);
  //   }


    //7-9
  //   int x;
  //   do {
  //     int n = readPlusInt();

  //     System.out.print("반대로 읽으면 ");
  //     while(n>0){
  //       System.out.print(n%10);
  //       n = n / 10;
  //     } 
  //     System.out.println(" 입니다.");

  //   do {
  //     System.out.print("다시 한번?<Yes...1/No...0>: ");
  //     x = sc.nextInt();
  //     } while(x!=0 && x != 1);
  //   }while (x == 1);
  // }

  // static int readPlusInt() {
  //   Scanner sc = new Scanner(System.in);
  //   int x;
  //   do {
  //     System.out.print("양의 정수: ");
  //     x = sc.nextInt();
  //   } while (x <= 0);
  //   return x;
  
  
    //7-10
  //   System.out.println("암산 훈련");
  //   do {
  //     int x = rand.nextInt(1000);
  //     int y = rand.nextInt(1000);
  //     int z = rand.nextInt(1000);
  //     int p = rand.nextInt(4);

  //     int answer = 0;
  //     switch(p) {
  //       case 1: answer = x+y+z; break;
  //       case 2: answer = x+y-z; break;
  //       case 3: answer = x-y+z; break;
  //       case 4: answer = x-y-z; break;
  //     }while(true) {
  //       System.out.print(x + ((p<2)? "+":"-") + y +((p%2==0) ? "+":"-")+z+"=");
  //       int k = sc.nextInt();
  //       if (k==answer)
  //         break;
  //       System.out.println("틀렸습니다.");
  //     }
  //   } while(retry());
    
  // }

  // static boolean retry() {
  //   Scanner sc = new Scanner(System.in);
  //   int cond;
  //   do {
  //     System.out.print("다시 한번<Yes...1/No...0>: ");
  //     cond = sc.nextInt();
  //   }while(cond != 0 && cond != 1);
  //   return cond == 1;
  
  
  
  
  
    //7-19
    System.out.print("요소수: ");
    int n = sc.nextInt();
    int[] a = new int[n];

    for (int i = 0; i <n; i++) {
      System.out.print("a[" + i + "] : ");
      a[i] = sc.nextInt();
    }

    System.out.print("삭제를 시작할 인덱스: ");
    int d = sc.nextInt();
    System.out.print("삭제할 요소의 수: ");
    int e = sc.nextInt();

    aryRmv(a, d, e);

    for(int i = 0; i < n; i++) {
      System.out.println("a[" + i + "] = " + a[i]);
    }
  }  

  static void aryRmv(int[] a, int d, int e) {
    if (e > 0 && d >= 0 && d+e < a.length) {
      int d2 = d + e - 1;
      if(d2 > a.length - e -1)
        d2 = a.length-e-1;
      for(int i = d; i <= d2; i++) {
        a[i] = a[i+e];
      }
    }
  }
}